# Calculator-Assignment

This repository contains code for calculator by using different method which are as follow:-

- `calculator_IF.html`  - Calculator using IF-else conditions
-  `Calculator_SWITCH.html` - Calculator using Switch conditions

Each calculator will prompt you for two numbers and an operator, then display the result in a popup.

## How it works
1. Click on any HTML file
2. Click the **Raw** button
3. Right-click → **Save As** to download the file
4. Double-click the file to open it in your browser


This assignment is part of my internship in Automation Testing.
  
